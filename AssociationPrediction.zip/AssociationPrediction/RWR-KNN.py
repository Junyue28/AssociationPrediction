import math
import os
import random
import time

import h5py
import numpy as np
import matplotlib.pyplot as plt
import sortscore
from sklearn.neighbors import KNeighborsClassifier
import sys

from SimilarityMatrixCalculation import GIP

sys.setrecursionlimit(100000)


def CA_DA(SC, SD, circnum, disnum, alpha, beta):
    CA = np.zeros((circnum, circnum))
    DA = np.zeros((disnum, disnum))
    for i in range(circnum):
        for j in range(circnum):
            if SC[i, j] >= alpha:
                CA[i, j] = 1
            else:
                CA[i, j] = 0
    for i in range(disnum):
        for j in range(disnum):
            if SD[i, j] >= beta:
                DA[i, j] = 1
            else:
                DA[i, j] = 0
    return CA, DA


def p(WMatrix, t, p0Matrix, r=0.7):
    if (t == 0):
        return p0Matrix
    else:
        return (1 - r) * np.matmul(WMatrix, p(WMatrix, t - 1, p0Matrix)) + r * p0Matrix


if __name__ == "__main__":
    fold_num = 5
    method_name = 'RWR-KNN'

    dataset_name = 'circ2Traits'
    with h5py.File(r'.\Data\circ2Traits\circRNA_disease.h5', 'r') as hf:
        circrna_disease_matrix = hf['infor'][:]

    # dataset_name = 'LncRNADiseaseV3'
    # Association_matrix_dir = r'.\Data\LncRNADiseaseV3\LncRNA_Disease_Association_matrix.tsv'
    # circrna_disease_matrix = np.loadtxt(Association_matrix_dir, delimiter='\t')
    # circrna_disease_matrix = matrix_sampling(circrna_disease_matrix, sampling_rate=(0.8, 1))

    # dataset_name = 'Lnc2CancerV3'
    # Association_matrix_dir = r'.\Data\Lnc2CancerV3\LncRNA_Disease_Association_matrix.tsv'
    # circrna_disease_matrix = np.loadtxt(Association_matrix_dir, delimiter='\t')

    # 5-fold cross-validation
    index_tuple = (np.where(circrna_disease_matrix == 1))
    one_list = list(zip(index_tuple[0], index_tuple[1]))
    random.shuffle(one_list)
    split = math.ceil(len(one_list) / fold_num)

    all_tpr = []
    all_fpr = []
    all_recall = []
    all_precision = []
    all_accuracy = []
    all_F1 = []
    alpha = 0.6
    beta = 0.8
    # 5-fold start
    for i in range(0, len(one_list), split):
        test_index = one_list[i:i + split]
        new_circrna_disease_matrix = circrna_disease_matrix.copy()
        # Erases the known relation, which refers to the node of value one in the A-matrix
        for index in test_index:
            new_circrna_disease_matrix[index[0], index[1]] = 0
        roc_circrna_disease_matrix = new_circrna_disease_matrix + circrna_disease_matrix
        rel_matrix = new_circrna_disease_matrix
        circnum = rel_matrix.shape[0]
        disnum = rel_matrix.shape[1]

        # make_sim_matrix = GIP(rel_matrix)
        # circ_gipsim_matrix, dis_gipsim_matrix = make_sim_matrix.circsimmatrix, make_sim_matrix.dissimmatrix
        circ_gipsim_matrix, dis_gipsim_matrix = GIP(rel_matrix)

        # with h5py.File('./Data/GIP_sim_matrix.h5', 'r') as hf:
        #     circ_gipsim_matrix = hf['circ_gipsim_matrix'][:]
        #     dis_gipsim_matrix = hf['dis_gipsim_matrix'][:]

        circnum = circrna_disease_matrix.shape[0]
        disnum = circrna_disease_matrix.shape[1]

        CA, DA = CA_DA(circ_gipsim_matrix, dis_gipsim_matrix, circnum, disnum, alpha, beta)

        # circ_dis=np.zeros((533 + 89, 533 * 89))

        circ_dis_label = []
        for i in range(rel_matrix.shape[0]):
            for j in range(rel_matrix.shape[1]):
                circ_dis_label.append(rel_matrix[i, j])

        # for i in range(circnum):
        #     for j in range(disnum):
        #         if j == 0:
        #             circ_dis[:, j] = (np.hstack((CA[i], DA[j]))).T
        #         else:
        #             circ_dis[:, i * j] = (np.hstack((CA[i], DA[j]))).T

        p0Matrix = np.zeros((circnum, circnum))
        for i in range(circnum):
            itemCircRNANum = np.sum(CA[i, :])
            for j in range(circnum):
                if (CA[i, j] == 1):
                    p0Matrix[j, i] = 1.0 / itemCircRNANum

        t = 1
        pt = p0Matrix
        CircRNANum = circnum * circnum

        CA_norm = CA / np.linalg.norm(CA)
        DA_norm = DA / np.linalg.norm(DA)

        while (True):
            pted1 = p(CA_norm, t, p0Matrix)
            Delta = abs(pted1 - pt)
            if (np.sum(Delta) / CircRNANum < 1e-6):
                break
            pt = pted1
            t += 1

        p0Matrix = np.zeros((disnum, disnum))
        for i in range(disnum):
            itemDiseaseNum = np.sum(DA[i, :])
            for j in range(disnum):
                if (DA[i, j] == 1):
                    p0Matrix[j, i] = 1.0 / itemDiseaseNum

        t = 1
        pt = p0Matrix
        DiseaseNum = disnum * disnum

        while (True):
            pted2 = p(DA_norm, t, p0Matrix)
            Delta = abs(pted2 - pt)
            if (np.sum(Delta) / DiseaseNum < 1e-6):
                break
            pt = pted2
            t += 1
        FSC = np.zeros((circnum, circnum))[:, 0]
        WSC = np.zeros((circnum, circnum))
        for i in range(circnum):
            for j in range(circnum):
                FSC[j] = pted1[i][j] * circ_gipsim_matrix[i][j]
            WSC[i] = FSC

        FSD = np.zeros((disnum, disnum))[:, 0]
        WSD = np.zeros((disnum, disnum))
        for i in range(disnum):
            for j in range(disnum):
                FSD[j] = pted2[i, j] * dis_gipsim_matrix[i, j]
            WSD[i] = FSD

        Circ_Dis = []

        # for i in range(circnum):
        #     for j in range(disnum):
        #         if j==0:
        #             Circ_Dis[:,j]=(np.hstack((pted1[i],pted2[j]))).T
        #         else:
        #             Circ_Dis[:,i*j]=(np.hstack((pted1[i],pted2[j]))).T

        for i in range(rel_matrix.shape[0]):
            for j in range(rel_matrix.shape[1]):
                circ_dis_input = []
                circ_feature = WSC[i, :]
                dis_feature = WSD[j, :]
                circ_dis_input += circ_feature.tolist()
                circ_dis_input += dis_feature.tolist()
                Circ_Dis.append(circ_dis_input)

        kn_clf = KNeighborsClassifier(n_neighbors=5)
        # kn_clf.fit(Circ_Dis, circ_dis)
        kn_clf.fit(Circ_Dis, circ_dis_label)
        kn_y = kn_clf.predict_proba(Circ_Dis)[:, 1]

        cd = np.zeros((circnum, disnum))

        np.array(kn_y).reshape((circnum, disnum))
        for i in range(cd.shape[0]):
            for j in range(cd.shape[1]):
                cd[i, j] = kn_y[i * disnum + j]

        # for k in range(disnum*circnum):
        #     i = k / circnum
        #     j = k % disnum
        #     if kn_y[:,k]==Circ_Dis[:,k]:
        #         cd[i][j]=1
        #     else:
        #         cd[i][j]=0

        prediction_matrix = cd
        aa = prediction_matrix.shape
        bb = roc_circrna_disease_matrix.shape
        zero_matrix = np.zeros((prediction_matrix.shape[0], prediction_matrix.shape[1]))
        print(prediction_matrix.shape)
        print(roc_circrna_disease_matrix.shape)

        score_matrix_temp = prediction_matrix.copy()
        score_matrix = score_matrix_temp + zero_matrix
        minvalue = np.min(score_matrix)
        score_matrix[np.where(roc_circrna_disease_matrix == 2)] = minvalue - 20
        sorted_circrna_disease_matrix, sorted_score_matrix, sort_index = sortscore.sort_matrix(score_matrix,
                                                                                               roc_circrna_disease_matrix)

        tpr_list = []
        fpr_list = []
        recall_list = []
        precision_list = []
        accuracy_list = []
        F1_list = []
        for cutoff in range(sorted_circrna_disease_matrix.shape[0]):
            P_matrix = sorted_circrna_disease_matrix[0:cutoff + 1, :]
            N_matrix = sorted_circrna_disease_matrix[cutoff + 1:sorted_circrna_disease_matrix.shape[0] + 1, :]
            TP = np.sum(P_matrix == 1)
            FP = np.sum(P_matrix == 0)
            TN = np.sum(N_matrix == 0)
            FN = np.sum(N_matrix == 1)
            tpr = TP / (TP + FN)
            fpr = FP / (FP + TN)
            tpr_list.append(tpr)
            fpr_list.append(fpr)
            recall = TP / (TP + FN)
            precision = TP / (TP + FP)
            recall_list.append(recall)
            precision_list.append(precision)
            accuracy = (TN + TP) / (TN + TP + FN + FP)
            F1 = (2 * TP) / (2 * TP + FP + FN)
            F1_list.append(F1)
            accuracy_list.append(accuracy)

        # top_list = [50, 100, 200]
        # for num in top_list:
        #     P_matrix = sorted_circrna_disease_matrix[0:num, :]
        #     N_matrix = sorted_circrna_disease_matrix[num:sorted_circrna_disease_matrix.shape[0] + 1, :]
        #     top_count = np.sum(P_matrix == 1)
        #     print("top" + str(num) + ": " + str(top_count))

        all_tpr.append(tpr_list)
        all_fpr.append(fpr_list)
        all_recall.append(recall_list)
        all_precision.append(precision_list)
        all_accuracy.append(accuracy_list)
        all_F1.append(F1_list)

    tpr_arr = np.array(all_tpr)
    fpr_arr = np.array(all_fpr)
    recall_arr = np.array(all_recall)
    precision_arr = np.array(all_precision)
    accuracy_arr = np.array(all_accuracy)
    F1_arr = np.array(all_F1)

    mean_cross_tpr = np.mean(tpr_arr, axis=0)  # axis=0
    mean_cross_fpr = np.mean(fpr_arr, axis=0)
    mean_cross_recall = np.mean(recall_arr, axis=0)
    mean_cross_precision = np.mean(precision_arr, axis=0)
    mean_cross_accuracy = np.mean(accuracy_arr, axis=0)

    mean_accuracy = np.mean(np.mean(accuracy_arr, axis=1), axis=0)
    mean_recall = np.mean(np.mean(recall_arr, axis=1), axis=0)
    mean_precision = np.mean(np.mean(precision_arr, axis=1), axis=0)
    mean_F1 = np.mean(np.mean(F1_arr, axis=1), axis=0)
    print("accuracy:%.4f,recall:%.4f,precision:%.4f,F1:%.4f" % (mean_accuracy, mean_recall, mean_precision, mean_F1))

    roc_auc = np.trapz(mean_cross_tpr, mean_cross_fpr)
    AUPR = np.trapz(mean_cross_precision, mean_cross_recall)
    print("AUC:%.4f,AUPR:%.4f" % (roc_auc, AUPR))

    # save
    result_npz_save_dir = f'./FinalResultNpz/{dataset_name}'
    if not os.path.exists(result_npz_save_dir):
        os.makedirs(result_npz_save_dir)
    np.savez(f'./FinalResultNpz/{dataset_name}/AllResult_{dataset_name}_{str(fold_num)}-fold_{method_name}.npz',
             tpr_arr=tpr_arr, fpr_arr=fpr_arr, recall_arr=recall_arr, precision_arr=precision_arr,
             accuracy_arr=accuracy_arr, F1_arr=F1_arr,
             mean_cross_tpr=mean_cross_tpr, mean_cross_fpr=mean_cross_fpr, mean_cross_recall=mean_cross_recall,
             mean_cross_precision=mean_cross_precision, mean_cross_accuracy=mean_cross_accuracy,
             mean_accuracy=mean_accuracy, mean_recall=mean_recall, mean_precision=mean_precision, mean_F1=mean_F1)

    plt.plot(mean_cross_fpr, mean_cross_tpr, label='mean ROC=%0.4f' % roc_auc)
    plt.xlabel('False Positive Rate')
    plt.ylabel('True Positive Rate')
    plt.legend(loc=0)
    plt.savefig(f'./FinalResultPng/roc_{dataset_name}_{str(fold_num)}-fold_{method_name}.png')
    print("runtime over, now is :")
    print(time.strftime('%Y-%m-%d %H:%M:%S', time.localtime(time.time())))
    # plt.show()
