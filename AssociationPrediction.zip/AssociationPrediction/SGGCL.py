import math
import os
import random
import h5py
import numpy as np
import matplotlib.pyplot as plt
from sklearn import svm
from sklearn.neighbors import KNeighborsClassifier
from xgboost import XGBClassifier
import sortscore
import argparse
import time
from sklearn.preprocessing import minmax_scale
import torch
import torch.nn as nn
import torch.nn.functional as F
from SimilarityMatrixCalculation import GIP, CosSim
from torch_geometric.nn import GCNConv, global_mean_pool
import torch.optim as optim
import scipy.sparse as sp
# from pyrwr1.rwr import RWR
from pyrwr1.pyrwr.rwr import RWR
from RWR import rwr
from sklearn.ensemble import GradientBoostingClassifier, RandomForestClassifier, AdaBoostClassifier, ExtraTreesClassifier


# class GCN(torch.nn.Module):
#     def __init__(self, in_dim, hidden_dim, out_dim):
#         super().__init__()
#         self.conv1 = GCNConv(in_dim, hidden_dim)
#         self.conv2 = GCNConv(hidden_dim, hidden_dim)
#         self.conv3 = GCNConv(hidden_dim, out_dim)
#
#     def forward(self, data):
#         x, edge_index = data.x, data.edge_index
#
#         x = self.conv1(x, edge_index)
#         x = F.relu(x)
#         # x = F.dropout(x, training=self.training)
#         x = self.conv2(x, edge_index)
#         x = F.relu(x)
#         # x = F.dropout(x, training=self.training)
#         x = self.conv3(x, edge_index)
#         return x


class GCN(torch.nn.Module):
    def __init__(self, in_dim, hidden_dim, out_dim):
        super().__init__()
        self.conv1 = GCNConv(in_dim, hidden_dim)
        self.conv2 = GCNConv(hidden_dim, hidden_dim)
        self.conv3 = GCNConv(hidden_dim, out_dim)

    def encode(self, x, edge_index):
        x = self.conv1(x, edge_index)
        x = F.relu(x)
        # x = F.dropout(x, training=self.training)
        # x = self.conv2(x, edge_index)
        # x = F.relu(x)
        # x = F.dropout(x, training=self.training)
        x = self.conv3(x, edge_index)
        # x = F.relu(x)
        # x = F.sigmoid(x)
        return x

    def decode(self, z, pos_edge_index, neg_edge_index):
        edge_index = torch.cat([pos_edge_index, neg_edge_index], dim=-1)
        return (z[edge_index[0]] * z[edge_index[1]]).sum(dim=-1)

    # def decode_all(self, z):
    #     prob_adj = z @ z.t()
    #     return (prob_adj > 0).nonzero(as_tuple=False).t()

    def decode_all(self, z, rna_num):
        prob_adj = z[:rna_num, :] @ z[rna_num:, :].t()
        return torch.sigmoid(prob_adj)


# MLP Layer used after graph vector representation
class projection_head(nn.Module):

    def __init__(self, input_dim, output_dim):
        super().__init__()
        self.fc_layer1 = nn.Linear(input_dim, output_dim, bias=True)
        self.fc_layer2 = nn.Linear(input_dim, output_dim, bias=True)

    def forward(self, x):
        x = self.fc_layer1(x)
        x = F.relu(x)
        x = self.fc_layer2(x)
        return x


class SGGCL(torch.nn.Module):
    def __init__(self, in_dim, hidden_dim, out_dim, projection_head_type=None):
        super().__init__()
        self.projection_head_type = projection_head_type

        self.gcn_model = GCN(in_dim, hidden_dim, out_dim)

        if projection_head_type == 'linear':
            self.projection_head_1 = torch.nn.Linear(in_dim, in_dim)
        elif projection_head_type == 'MLP':
            self.projection_head_1 = projection_head(in_dim, in_dim)

    def forward(self, x, edge_index):

        x = self.gcn_model.encode(x, edge_index)

        if self.projection_head_type is None:
            node_features = torch.mean(x, dim=0, keepdim=True)
        else:
            node_features = torch.mean(x, dim=0, keepdim=True)
            node_features = self.projection_head_1(node_features)

        return x, node_features, self.gcn_model


parser = argparse.ArgumentParser()

parser.add_argument('--in_dim', type=int, default=500,
                    help='Dimension of input representations')
parser.add_argument('--hidden_dim', type=int, default=256,
                    help='Dimension of GCN representations')
parser.add_argument('--out_dim', type=int, default=256,
                    help='Dimension of output representations')
parser.add_argument('--projection_head_type', type=str, default='linear',
                    help='Projection head type: None, linear, MLP')
parser.add_argument('--similarity_weight', type=float, default=0.5,
                    help='Weight between GIP and CosSim')
parser.add_argument('--anchor_threshold', type=float, default=0.9,
                    help='Anchor fusion similarity threshold')
parser.add_argument('--augmentation_rate', type=float, default=0.1,
                    help='Positive or negative augmentation rate')

parser.add_argument('--no-cuda', action='store_true', default=False,
                    help='Disables CUDA training')
parser.add_argument('--seed', type=int, default=7, help='Random seed')
parser.add_argument('--epochs', type=int, default=1000,
                    help='Number of epochs to train')
parser.add_argument('--learning_rate', type=float, default=0.0001,
                    help='Learning rate')
parser.add_argument('--weight_decay', type=float, default=1e-5,
                    help='Weight decay (L2 loss on parameters).')

# parser.add_argument('--data', type=int, default=1, choices=[1, 2],
#                     help='Dataset')

args = parser.parse_args()
args.cuda = not args.no_cuda and torch.cuda.is_available()


def set_seed(seed, cuda):
    np.random.seed(seed)
    torch.manual_seed(seed)
    if cuda:
        torch.cuda.manual_seed(seed)


# set_seed(args.seed, args.cuda)


def neighborhood(feat, k):
    # print("This is neighborhood...")
    # compute C
    featprod = np.dot(feat.T, feat)
    smat = np.tile(np.diag(featprod), (feat.shape[1], 1))
    dmat = smat + smat.T - 2 * featprod
    dsort = np.argsort(dmat)[:, 1:k + 1]
    C = np.zeros((feat.shape[1], feat.shape[1]))
    for i in range(feat.shape[1]):
        for j in dsort[i]:
            C[i, j] = 1.0

    return C


def classifiers(train_data, test_data, classifier_name, custom_method, metrics):
    # AdaBoostClassifier, SVM , GradientBoostingClassifier, RandomForestClassifier, ExtraTreesClassifier, XGBoost
    if classifier_name == 'AdaBoostClassifier':
        predictor = AdaBoostClassifier(n_estimators=50)
        predictor.fit(train_data[0], train_data[1])
    elif classifier_name == 'SVM':
        predictor = svm.SVC(gamma='scale', C=1.0, decision_function_shape='ovr',
                            kernel='rbf')  # linear, poly, rbf, sigmod
    elif classifier_name == 'GradientBoostingClassifier':
        predictor = GradientBoostingClassifier(n_estimators=100, max_depth=9)
        # predictor = predictor.fit(train_data[0], train_data[1])
        # score = predictor.score(test_data[0])
    elif classifier_name == 'RandomForestClassifier':
        predictor = RandomForestClassifier(n_estimators=500, max_depth=7)
    elif classifier_name == 'KNeighborsClassifier':
        predictor = KNeighborsClassifier()
    elif classifier_name == 'XGBoost':
        predictor = XGBClassifier(n_estimators=200, max_depth=7, objective='binary:logistic')
    else:
        predictor = custom_method()
    predictor.fit(train_data[0], train_data[1])
    res = predictor.predict(test_data[0])
    metrics(res, test_data[1])


def normalized(wmat):
    # print("This is normalized...")
    deg = np.diag(np.sum(wmat, axis=0))
    degpow = np.power(deg, -0.5)
    degpow[np.isinf(degpow)] = 0
    W = np.dot(np.dot(degpow, wmat), degpow)
    return W


def norm_adj(feat):
    # print("This is norm_adj...")
    C = neighborhood(feat.T, k=10)
    norm_adj = normalized(C.T * C + np.eye(C.shape[0]))
    g = torch.from_numpy(norm_adj).float()
    return g


def normalization(adjacency):
    """
    degree matrix
    L=D^-0.5 * (A+I) * D^-0.5
    """
    # adjacency += sp.eye(adjacency.shape[0])
    adjacency = sp.coo_matrix(adjacency)
    degree = np.array(adjacency.sum(1))
    d_hat = sp.diags(np.power(degree, -0.5).flatten())
    adj_normalized = d_hat.dot(adjacency).dot(d_hat).tocoo()
    adj_normalized = sp.csc_matrix.todense(adj_normalized)
    return adj_normalized


def similarity_calculation(rel_matrix, args):
    # new_rel_matrix = rel_matrix.copy()

    # GIP and CosSim weight
    similarity_weight = args.similarity_weight

    print('Similarity computing...')
    # Gaussian interaction profile kernel similarity
    LGS, DGS = GIP(rel_matrix)

    # Cosine similarity
    LCS, DCS = CosSim(rel_matrix)

    # Fusion similarity
    LGCS = similarity_weight * LGS + (1 - similarity_weight) * LCS
    DGCS = similarity_weight * DGS + (1 - similarity_weight) * DCS

    print('Complete similarity calculation!')
    return LGCS, DGCS


def similarity_guidance_graph_augmentation(similarity_matrix, similarity_binary_matrix, args, orientation=1):

    augmentation_rate = args.augmentation_rate / 2

    if orientation > 0:
        ii, jj = np.where(similarity_matrix >= 0.5)
    else:
        ii, jj = np.where(similarity_matrix < 0.5)

    ix = np.random.choice(len(ii), int(np.floor(augmentation_rate * len(ii))), replace=False)

    similarity_binary_matrix[ii[ix], jj[ix]] = 1
    similarity_binary_matrix[jj[ix], ii[ix]] = 1

    return similarity_binary_matrix


def set_model(args, in_out_dim):
    ConLoss = nn.TripletMarginLoss()
    BCELoss = nn.BCEWithLogitsLoss()
    model = SGGCL(in_out_dim, args.hidden_dim, in_out_dim, args.projection_head_type)

    return model, ConLoss, BCELoss


def set_optimizer(args, model):
    optimizer = optim.Adam(model.parameters(), lr=args.learning_rate, weight_decay=args.weight_decay)
    return optimizer


def get_link_labels(pos_edge_index, neg_edge_index):
    num_links = pos_edge_index.size(1) + neg_edge_index.size(1)
    link_labels = torch.zeros(num_links, dtype=torch.float)
    link_labels[:pos_edge_index.size(1)] = 1
    return link_labels


def negative_sampling(negative_edge_index, positive_edge_num):
    temp_idx = np.random.choice(np.arange(negative_edge_index[0].shape[0]),
                                size=positive_edge_num, replace=False)
    return (negative_edge_index[0][temp_idx], negative_edge_index[1][temp_idx])


if __name__ == "__main__":
    fold_num = 5
    method_name = 'SGGCL'
    no_classifier = False

    dataset_name = 'circ2Traits'
    with h5py.File(r'.\Data\circ2Traits\circRNA_disease.h5', 'r') as hf:
        circrna_disease_matrix = hf['infor'][:]

    # dataset_name = 'LncRNADiseaseV3'
    # Association_matrix_dir = r'.\Data\LncRNADiseaseV3\LncRNA_Disease_Association_matrix.tsv'
    # circrna_disease_matrix = np.loadtxt(Association_matrix_dir, delimiter='\t')
    # circrna_disease_matrix = matrix_sampling(circrna_disease_matrix, sampling_rate=(0.8, 1))

    # dataset_name = 'Lnc2CancerV3'
    # Association_matrix_dir = r'.\Data\Lnc2CancerV3\LncRNA_Disease_Association_matrix.tsv'
    # circrna_disease_matrix = np.loadtxt(Association_matrix_dir, delimiter='\t')

    # 5-fold cross-validation
    index_tuple = (np.where(circrna_disease_matrix == 1))
    one_list = list(zip(index_tuple[0], index_tuple[1]))
    random.shuffle(one_list)
    split = math.ceil(len(one_list) / fold_num)

    all_tpr = []
    all_fpr = []
    all_recall = []
    all_precision = []
    all_accuracy = []
    all_F1 = []

    # 5-fold start
    for i in range(0, len(one_list), split):
        test_index = one_list[i:i + split]
        new_circrna_disease_matrix = circrna_disease_matrix.copy()
        # Erases the known relation, which refers to the node of value one in the A-matrix
        for index in test_index:
            new_circrna_disease_matrix[index[0], index[1]] = 0
        roc_circrna_disease_matrix = new_circrna_disease_matrix + circrna_disease_matrix
        rel_matrix = new_circrna_disease_matrix
        circnum = rel_matrix.shape[0]
        disnum = rel_matrix.shape[1]

        train_negative_edge_index = np.where(circrna_disease_matrix == 0)
        train_positive_edge_index = np.where(rel_matrix == 1)
        positive_edge_num = train_positive_edge_index[0].shape[0]

        LGCS, DGCS = similarity_calculation(rel_matrix, args)
        temp_anchor_threshold = args.anchor_threshold
        LGCS_binary = np.where(LGCS >= temp_anchor_threshold, 1, 0)
        DGCS_binary = np.where(DGCS >= temp_anchor_threshold, 1, 0)

        model, ConLoss, BCELoss = set_model(args, in_out_dim=(circnum + disnum))
        if args.cuda:
            model = model.cuda()
            ConLoss = ConLoss.cuda()
            BCELoss = BCELoss.cuda()

        optimizer = set_optimizer(args, model)

        for e in range(args.epochs):
            # anchor
            anchor_matrix = np.vstack((np.hstack((LGCS_binary, rel_matrix)),
                                       np.hstack((rel_matrix.T, DGCS_binary))))

            # positive
            LGCS_binary_1 = similarity_guidance_graph_augmentation(LGCS, LGCS_binary, args, orientation=1)
            DGCS_binary_1 = similarity_guidance_graph_augmentation(DGCS, DGCS_binary, args, orientation=1)
            positive_matrix = np.vstack((np.hstack((LGCS_binary_1, rel_matrix)),
                                         np.hstack((rel_matrix.T, DGCS_binary_1))))

            # negative
            LGCS_binary_0 = similarity_guidance_graph_augmentation(LGCS, LGCS_binary, args, orientation=0)
            DGCS_binary_0 = similarity_guidance_graph_augmentation(DGCS, DGCS_binary, args, orientation=0)
            negative_matrix = np.vstack((np.hstack((LGCS_binary_0, rel_matrix)),
                                         np.hstack((rel_matrix.T, DGCS_binary_0))))

            # anchor_matrix = normalization(anchor_matrix)

            anchor_matrix_rwr = rwr(anchor_matrix)
            positive_matrix_rwr = rwr(positive_matrix)
            negative_matrix_rwr = rwr(negative_matrix)

            anchor_matrix = torch.from_numpy(anchor_matrix).float()
            positive_matrix = torch.from_numpy(positive_matrix).float()
            negative_matrix = torch.from_numpy(negative_matrix).float()

            # anchor_matrix = norm_adj(anchor_matrix)
            # positive_matrix = norm_adj(positive_matrix)
            # negative_matrix = norm_adj(negative_matrix)
            if args.cuda:
                anchor_matrix = anchor_matrix.cuda()
                positive_matrix = positive_matrix.cuda()
                negative_matrix = negative_matrix.cuda()

            train_negative_edge_index = negative_sampling(train_negative_edge_index, positive_edge_num)

            # new_Disease_idx = Disease_idx + RNA_num
            new_train_positive_edge_index = torch.tensor(
                np.array([train_positive_edge_index[0], train_positive_edge_index[1] + circnum]))
            new_train_negative_edge_index = torch.tensor(
                np.array([train_negative_edge_index[0], train_negative_edge_index[1] + circnum]))
            if args.cuda:
                new_train_positive_edge_index = new_train_positive_edge_index.cuda()
                new_train_negative_edge_index = new_train_negative_edge_index.cuda()
            model.train()

            output, anchor_features, net = model(anchor_matrix, new_train_positive_edge_index)
            _, positive_features, _ = model(positive_matrix, new_train_positive_edge_index)
            _, negative_features, _ = model(negative_matrix, new_train_positive_edge_index)

            link_logits = net.decode(output, new_train_positive_edge_index, new_train_negative_edge_index)

            link_labels = get_link_labels(new_train_positive_edge_index, new_train_negative_edge_index)
            if args.cuda:
                link_labels = link_labels.cuda()

            con_loss = ConLoss(anchor_features, positive_features, negative_features)
            BCE_loss = BCELoss(link_logits, link_labels)
            loss = con_loss + BCE_loss
            # loss = BCE_loss
            optimizer.zero_grad()
            loss.backward()
            optimizer.step()
            print(f'TotalLoss:{loss}, ConLoss:{con_loss}, BCELoss:{BCE_loss}')

        if no_classifier:
            model.eval()
            prediction_matrix = net.decode_all(output, circnum).detach().cpu().numpy()

            # prediction_matrix = np.where(prediction_matrix > 0.5, 1, 0)
            # temp_matrix = np.abs(prediction_matrix - circrna_disease_matrix).sum()
            # print(temp_matrix / (circnum * disnum))

            aa = prediction_matrix.shape
            bb = roc_circrna_disease_matrix.shape
            zero_matrix = np.zeros((prediction_matrix.shape[0], prediction_matrix.shape[1]))
            print(prediction_matrix.shape)
            print(roc_circrna_disease_matrix.shape)

            score_matrix_temp = prediction_matrix.copy()
            score_matrix = score_matrix_temp + zero_matrix
            minvalue = np.min(score_matrix)
            score_matrix[np.where(roc_circrna_disease_matrix == 2)] = minvalue - 20
            sorted_circrna_disease_matrix, sorted_score_matrix, sort_index = sortscore.sort_matrix(score_matrix,
                                                                                                   roc_circrna_disease_matrix)

            tpr_list = []
            fpr_list = []
            recall_list = []
            precision_list = []
            accuracy_list = []
            F1_list = []
            for cutoff in range(sorted_circrna_disease_matrix.shape[0]):
                P_matrix = sorted_circrna_disease_matrix[0:cutoff + 1, :]
                N_matrix = sorted_circrna_disease_matrix[cutoff + 1:sorted_circrna_disease_matrix.shape[0] + 1, :]
                TP = np.sum(P_matrix == 1)
                FP = np.sum(P_matrix == 0)
                TN = np.sum(N_matrix == 0)
                FN = np.sum(N_matrix == 1)
                tpr = TP / (TP + FN)
                fpr = FP / (FP + TN)
                tpr_list.append(tpr)
                fpr_list.append(fpr)
                recall = TP / (TP + FN)
                precision = TP / (TP + FP)
                recall_list.append(recall)
                precision_list.append(precision)
                accuracy = (TN + TP) / (TN + TP + FN + FP)
                F1 = (2 * TP) / (2 * TP + FP + FN)
                if (2 * TP + FP + FN) == 0:
                    F1 = 0
                F1_list.append(F1)
                accuracy_list.append(accuracy)

            # top_list = [50, 100, 200]
            # for num in top_list:
            #     P_matrix = sorted_circrna_disease_matrix[0:num, :]
            #     N_matrix = sorted_circrna_disease_matrix[num:sorted_circrna_disease_matrix.shape[0] + 1, :]
            #     top_count = np.sum(P_matrix == 1)
            #     print("top" + str(num) + ": " + str(top_count))

            ################################
            tpr_arr_epoch = np.array(tpr_list)
            fpr_arr_epoch = np.array(fpr_list)
            recall_arr_epoch = np.array(recall_list)
            precision_arr_epoch = np.array(precision_list)
            accuracy_arr_epoch = np.array(accuracy_list)
            F1_arr_epoch = np.array(F1_list)
            # print("epoch,",epoch)
            print("accuracy:%.4f,recall:%.4f,precision:%.4f,F1:%.4f" % (
                np.mean(accuracy_arr_epoch), np.mean(recall_arr_epoch), np.mean(precision_arr_epoch),
                np.mean(F1_arr_epoch)))
            print("roc_auc", np.trapz(tpr_arr_epoch, fpr_arr_epoch))
            print("AUPR", np.trapz(precision_arr_epoch, recall_arr_epoch))

            # print("TP=%d, FP=%d, TN=%d, FN=%d" % (TP, FP, TN, FN))
            print("roc_auc", np.trapz(tpr_arr_epoch, fpr_arr_epoch))
            ################################

            all_tpr.append(tpr_list)
            all_fpr.append(fpr_list)
            all_recall.append(recall_list)
            all_precision.append(precision_list)
            all_accuracy.append(accuracy_list)
            all_F1.append(F1_list)
        else:
            outs = output.detach().cpu().numpy()
            np.save(f'./save/outs_fold_{i}.npy', outs)

    if no_classifier:
        tpr_arr = np.array(all_tpr)
        fpr_arr = np.array(all_fpr)
        recall_arr = np.array(all_recall)
        precision_arr = np.array(all_precision)
        accuracy_arr = np.array(all_accuracy)
        F1_arr = np.array(all_F1)

        mean_cross_tpr = np.mean(tpr_arr, axis=0)  # axis=0
        mean_cross_fpr = np.mean(fpr_arr, axis=0)
        mean_cross_recall = np.mean(recall_arr, axis=0)
        mean_cross_precision = np.mean(precision_arr, axis=0)
        mean_cross_accuracy = np.mean(accuracy_arr, axis=0)

        mean_accuracy = np.mean(np.mean(accuracy_arr, axis=1), axis=0)
        mean_recall = np.mean(np.mean(recall_arr, axis=1), axis=0)
        mean_precision = np.mean(np.mean(precision_arr, axis=1), axis=0)
        mean_F1 = np.mean(np.mean(F1_arr, axis=1), axis=0)

        print("accuracy:%.4f,recall:%.4f,precision:%.4f,F1:%.4f" % (mean_accuracy, mean_recall, mean_precision, mean_F1))

        roc_auc = np.trapz(mean_cross_tpr, mean_cross_fpr)
        AUPR = np.trapz(mean_cross_precision, mean_cross_recall)

        print("AUC:%.4f,AUPR:%.4f" % (roc_auc, AUPR))

        # save
        result_npz_save_dir = f'./FinalResultNpz/{dataset_name}'
        if not os.path.exists(result_npz_save_dir):
            os.makedirs(result_npz_save_dir)
        np.savez(f'./FinalResultNpz/{dataset_name}/AllResult_{dataset_name}_{str(fold_num)}-fold_{method_name}.npz',
                 tpr_arr=tpr_arr, fpr_arr=fpr_arr, recall_arr=recall_arr, precision_arr=precision_arr,
                 accuracy_arr=accuracy_arr, F1_arr=F1_arr,
                 mean_cross_tpr=mean_cross_tpr, mean_cross_fpr=mean_cross_fpr, mean_cross_recall=mean_cross_recall,
                 mean_cross_precision=mean_cross_precision, mean_cross_accuracy=mean_cross_accuracy,
                 mean_accuracy=mean_accuracy, mean_recall=mean_recall, mean_precision=mean_precision, mean_F1=mean_F1)

        plt.plot(mean_cross_fpr, mean_cross_tpr, label='mean ROC=%0.4f' % roc_auc)
        plt.xlabel('False Positive Rate')
        plt.ylabel('True Positive Rate')
        plt.legend(loc=0)
        plt.savefig(f'./FinalResultPng/roc_{dataset_name}_{str(fold_num)}-fold_{method_name}.png')
        print("runtime over, now is :")
        print(time.strftime('%Y-%m-%d %H:%M:%S', time.localtime(time.time())))
        # plt.show()
