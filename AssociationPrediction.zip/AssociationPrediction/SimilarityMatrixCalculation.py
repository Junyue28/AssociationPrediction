import numpy as np
import numpy.linalg as LA


# Gaussian interaction profile kernel similarity
def GIP(A):  # A is numpy 2D array: association matrix
    gamad1 = 1
    sumk1 = 0
    ss = A.shape[1]
    for nm in range(ss):
        sumk1 = sumk1 + LA.norm(A[:, nm], ord=2) ** 2
    gamaD1 = gamad1 * ss / sumk1
    DGS = np.zeros((ss, ss))
    for ab in range(ss):
        for ba in range(ab + 1):
            DGS[ab, ba] = DGS[ba, ab] = np.exp(-gamaD1 * LA.norm(A[:, ab] - A[:, ba]) ** 2)

    gamad2 = 1
    sumk2 = 0
    mm = A.shape[0]
    for mn in range(mm):
        sumk2 = sumk2 + LA.norm(A[mn, :], ord=2) ** 2
    gamaD2 = gamad2 * mm / sumk2
    LGS = np.zeros((mm, mm))
    for cd in range(mm):
        for dc in range(cd + 1):
            LGS[cd, dc] = LGS[dc, cd] = np.exp(-gamaD2 * LA.norm(A[cd, :] - A[dc, :]) ** 2)
    return LGS, DGS  # LncRNA:LGS, Disease:DGS


# Cosine similarity
def CosSim(A):  # A is numpy 2D array: association matrix
    ll = A.shape[0]
    LCS = np.zeros((ll, ll))
    for ab in range(ll):
        for ba in range(ab + 1):
            # LCS[ab, ba] = LCS[ba, ab] = (A[ab, :].dot(A[ba, :])) / (LA.norm(A[ab, :]) * LA.norm(A[ba, :]))
            LCS[ab, ba] = LCS[ba, ab] = (A[ab, :].dot(A[ba, :]) + 1e-7) / (
                    (LA.norm(A[ab, :]) * LA.norm(A[ba, :])) + 1e-7)
    dd = A.shape[1]
    DCS = np.zeros((dd, dd))
    for cd in range(dd):
        for dc in range(cd + 1):
            # DCS[cd, dc] = DCS[dc, cd] = (A[:, cd].dot(A[:, dc])) / (LA.norm(A[:, cd]) * LA.norm(A[:, dc]))
            DCS[cd, dc] = DCS[dc, cd] = (A[:, cd].dot(A[:, dc]) + 1e-7) / (
                    (LA.norm(A[:, cd]) * LA.norm(A[:, dc])) + 1e-7)
    return LCS, DCS


if __name__ == '__main__':
    # Gaussian interaction profile kernel similarity
    # Association_matrix_dir = r'.\Data\LncRNADisease v3.0\Preprocessed\LncRNA_Disease_Association_matrix.tsv'
    # Association_matrix = np.loadtxt(Association_matrix_dir, delimiter='\t')
    # LGS, DGS = GIP(Association_matrix)
    # np.savetxt(r'.\LGS.tsv', np.around(LGS, 3), fmt='%s', delimiter='\t')
    # np.savetxt(r'.\DGS.tsv', np.around(DGS, 3), fmt='%s', delimiter='\t')
    # print('ok!')

    # Cosine similarity
    # Association_matrix_dir = r'.\Data\LncRNADisease v3.0\Preprocessed\LncRNA_Disease_Association_matrix.tsv'
    # Association_matrix = np.loadtxt(Association_matrix_dir, delimiter='\t')
    # LCS, DCS = CosSim(Association_matrix)
    # np.savetxt(r'.\LCS.tsv', np.around(LCS, 3), fmt='%s', delimiter='\t')
    # np.savetxt(r'.\DCS.tsv', np.around(DCS, 3), fmt='%s', delimiter='\t')
    # print('ok!')
    pass
