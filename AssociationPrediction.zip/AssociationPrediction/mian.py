import torch

if __name__ == '__main__':
    print(torch.__version__)
    print('torch.cuda.device_count(): ', torch.cuda.device_count())
