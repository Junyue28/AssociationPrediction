import numpy as np
import torch
import torch.nn.functional as F
from torch.nn import Linear
from torch_geometric.nn import GCNConv
from torch_geometric.datasets import Planetoid
from torch_geometric.loader import DataLoader
from torch_geometric.utils import to_networkx
from torch_geometric.nn import global_mean_pool
import networkx as nx
import matplotlib.pyplot as plt


class GCN(torch.nn.Module):
    def __init__(self, hidden_channels):
        super().__init__()
        self.conv1 = GCNConv(dataset.num_node_features, hidden_channels)
        self.conv2 = GCNConv(hidden_channels, hidden_channels)
        self.conv3 = GCNConv(hidden_channels, dataset.num_classes)

    def forward(self, data):
        x, edge_index = data.x, data.edge_index

        x = self.conv1(x, edge_index)
        x = F.relu(x)
        # x = F.dropout(x, training=self.training)
        x = self.conv2(x, edge_index)
        x = F.relu(x)
        # x = F.dropout(x, training=self.training)
        x = self.conv3(x, edge_index)
        return x


if __name__ == '__main__':
    dataset = Planetoid(root='./tmp/Cora', name='Cora')

    print(dataset.num_classes)
    print(dataset.num_edge_features)
    print(dataset.edge_index.shape[1] / 2)
    print(dataset.num_node_features)
    print(dataset.x.shape[0])

    CoraNet = to_networkx(dataset[0])  # type : networkx.classes.graph.Graph
    CoraNet = CoraNet.to_undirected()

    print(CoraNet.number_of_edges())
    print(CoraNet.number_of_nodes())
    Node_class = dataset.y.data.numpy()
    print(Node_class)

    # pos = nx.spring_layout(CoraNet)
    # nodecolor = ["red", "blue", "green", "yellow", "peru", "violet", "cyan"]
    # nodelabel = np.array(list(CoraNet.nodes))
    # plt.figure(figsize=(16, 12))
    #
    # for ii in np.arange(len(np.unique(Node_class))):
    #     nodelist = nodelabel[Node_class == ii]
    #     nx.draw_networkx_nodes(CoraNet, pos, nodelist=list(nodelist), node_size=20,
    #                            node_color=nodecolor[ii], alpha=0.8)
    #
    # nx.draw_networkx_edges(CoraNet, pos, width=1, edge_color="gray")
    # plt.show()

    model = GCN(hidden_channels=512)
    device = torch.device('cuda' if torch.cuda.is_available() else 'cpu')
    model = model.to(device)
    criterion = torch.nn.CrossEntropyLoss()  # Define loss criterion.
    opt = torch.optim.Adam(model.parameters(), lr=0.01, weight_decay=5e-4)  # Define optimizer.
    data = dataset[0].to(device)

    for i in range(200):
        out = model.forward(data)
        loss = criterion(out[data.train_mask], data.y[data.train_mask])
        opt.zero_grad()
        loss.backward()
        opt.step()

        pred = out.argmax(dim=1)  # Use the class with highest probability.
        test_correct = pred[data.test_mask] == data.y[data.test_mask]  # Check against ground-truth labels.
        test_acc = int(test_correct.sum()) / int(data.test_mask.sum())  # Derive ratio of correct predictions.

        print("epoch:{} , loss:{}, accracy:{}".format(i, loss, test_acc))
