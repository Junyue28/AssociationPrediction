import pandas as pd
import numpy as np
import numpy.linalg as LA


# LncRNADisease v3.0
def LncRNADiseaseV3():
    tsv_dir = r'.\Data\LncRNADisease v3.0\website_alldata.tsv'
    # tsv_dir = r'.\Data\LncRNADisease v3.0\website_causal_data.tsv'
    pd_data = pd.read_csv(tsv_dir, sep='\t')
    Homo_sapiens_data = pd_data[(pd_data['Species'] == 'Homo sapiens')]
    Homo_sapiens_LncRNA_data = Homo_sapiens_data[(Homo_sapiens_data['ncRNA Category'] == 'LncRNA')]
    LncRNA_name_list = Homo_sapiens_LncRNA_data['ncRNA Symbol'].unique()
    Disease_Name_list = Homo_sapiens_LncRNA_data['Disease Name'].unique()

    LncRNA_name_list_save_dir = r'.\Data\LncRNADisease v3.0\Preprocessed\LncRNA_name_list.tsv'
    np.savetxt(LncRNA_name_list_save_dir, LncRNA_name_list, delimiter='\t', fmt='%s', encoding='utf8')
    Disease_Name_list_save_dir = r'.\Data\LncRNADisease v3.0\Preprocessed\Disease_Name_list.tsv'
    np.savetxt(Disease_Name_list_save_dir, Disease_Name_list, delimiter='\t', fmt='%s', encoding='utf8')

    LncRNA_Disease_Association_matrix = np.zeros((len(LncRNA_name_list), len(Disease_Name_list)), dtype=int)
    for index, row in Homo_sapiens_LncRNA_data.iterrows():
        LncRNA_name_index = np.argwhere(LncRNA_name_list == row['ncRNA Symbol'])[0]
        Disease_name_index = np.argwhere(Disease_Name_list == row['Disease Name'])[0]
        LncRNA_Disease_Association_matrix[LncRNA_name_index, Disease_name_index] = 1
    LncRNA_Disease_Association_matrix_save_dir = r'.\Data\LncRNADisease v3.0\Preprocessed\LncRNA_Disease_Association_matrix.tsv'
    np.savetxt(LncRNA_Disease_Association_matrix_save_dir, LncRNA_Disease_Association_matrix, delimiter='\t', fmt='%d',
               encoding='utf8')

    LncRNA_Disease_Association_save_dir = r'.\Data\LncRNADisease v3.0\Preprocessed\LncRNA_Disease_Association.tsv'
    LncRNA_Disease_Association = Homo_sapiens_LncRNA_data[['ncRNA Symbol', 'Disease Name']]
    LncRNA_Disease_Association.to_csv(LncRNA_Disease_Association_save_dir, sep='\t', index=False)


# Lnc2Cancer 3.0
def Lnc2CancerV3():
    xlsx_dir = r'.\Data\Lnc2Cancer 3.0\LncRNA-Cancer Association\lncRNA.xlsx'
    pd_data = pd.read_excel(xlsx_dir)
    LncRNA_name_list = pd_data['name'].unique()
    Disease_Name_list = pd_data['cancer type'].unique()

    LncRNA_name_list_save_dir = r'.\Data\Lnc2Cancer 3.0\LncRNA-Cancer Association\Preprocessed\LncRNA_name_list.tsv'
    np.savetxt(LncRNA_name_list_save_dir, LncRNA_name_list, delimiter='\t', fmt='%s', encoding='utf8')
    Disease_Name_list_save_dir = r'.\Data\Lnc2Cancer 3.0\LncRNA-Cancer Association\Preprocessed\Disease_Name_list.tsv'
    np.savetxt(Disease_Name_list_save_dir, Disease_Name_list, delimiter='\t', fmt='%s', encoding='utf8')

    LncRNA_Disease_Association_matrix = np.zeros((len(LncRNA_name_list), len(Disease_Name_list)), dtype=int)
    for index, row in pd_data.iterrows():
        LncRNA_name_index = np.argwhere(LncRNA_name_list == row['name'])[0]
        Disease_name_index = np.argwhere(Disease_Name_list == row['cancer type'])[0]
        LncRNA_Disease_Association_matrix[LncRNA_name_index, Disease_name_index] = 1
    LncRNA_Disease_Association_matrix_save_dir = r'.\Data\Lnc2Cancer 3.0\LncRNA-Cancer Association\Preprocessed\LncRNA_Disease_Association_matrix.tsv'
    np.savetxt(LncRNA_Disease_Association_matrix_save_dir, LncRNA_Disease_Association_matrix, delimiter='\t', fmt='%d',
               encoding='utf8')

    LncRNA_Disease_Association_save_dir = r'.\Data\Lnc2Cancer 3.0\LncRNA-Cancer Association\Preprocessed\LncRNA_Disease_Association.tsv'
    LncRNA_Disease_Association = pd_data[['name', 'cancer type']]
    LncRNA_Disease_Association.to_csv(LncRNA_Disease_Association_save_dir, sep='\t', index=False)


if __name__ == '__main__':
    # LncRNADiseaseV3()
    # Lnc2CancerV3()
    pass
