__author__ = 'Jinhong Jung'
__email__ = 'jinhongjung@snu.ac.kr'
__version__ = '1.0.0'
